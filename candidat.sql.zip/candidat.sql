-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 13 oct. 2022 à 22:21
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `aeek_kassere`
--

-- --------------------------------------------------------

--
-- Structure de la table `candidat`
--

CREATE TABLE `candidat` (
  `id_candidat` int(11) NOT NULL,
  `date_candidat` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `fonction` varchar(225) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `nbvote` int(11) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `candidat`
--

INSERT INTO `candidat` (`id_candidat`, `date_candidat`, `nom`, `prenom`, `slug`, `fonction`, `bio`, `iso_phone`, `dial_phone`, `phone`, `photo`, `nbvote`, `status`) VALUES
(1, '2022-10-26 23:32:45', 'Ouattara', 'Yafe Adama', 'yafe-adama', 'Responsable à l\'organisation adjoint', 'Etudiant ayant le BTS en RHCOM', 'CI', '225', '00000000000', '63400bcbb0b81.jpg', 10, 0),
(2, '2022-10-26 19:59:09', 'Kone', 'Ban', 'ban', 'SAG', NULL, NULL, NULL, NULL, NULL, 0, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `candidat`
--
ALTER TABLE `candidat`
  ADD PRIMARY KEY (`id_candidat`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `candidat`
--
ALTER TABLE `candidat`
  MODIFY `id_candidat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
